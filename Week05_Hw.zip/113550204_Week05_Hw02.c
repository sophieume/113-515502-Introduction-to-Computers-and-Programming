#include <stdio.h>
#include <limits.h>

void addition(char* result, char* a, char* b) {
    int digitA = strlen(a);
    int digitB = strlen(b);
    int carry = 0;
    char temp[1050] = {0};
    int sum = 0;
    int i = 1;
    int k = 0;

    while (digitA - i >= 0 || digitB - i >= 0 || carry > 0) {
        int numA = (digitA - i >= 0) ? a[digitA - i] - '0' : 0;
        int numB = (digitB - i >= 0) ? b[digitB - i] - '0' : 0;

        sum = numA + numB + carry;
        carry = sum / 10;
        temp[k] = sum % 10 + '0';
        k++;
        i++;
    }

    for (int j = 0; j < k; j++) {
        result[j] = temp[k - j - 1];
    }
    result[k] = '\0';
}

int compare(char* a, char* b) {
    int digitA = strlen(a);
    int digitB = strlen(b);

    if (digitA > digitB) return 1;
    if (digitA < digitB) return 0;

    for (int i = 0; i < digitA; i++) {
        if (a[i] > b[i]) return 1;
        if (a[i] < b[i]) return 0;
    }
    return 0;
}

void multiply(char* result, char* a, int b) {
    int digitA = strlen(a);
    int carry = 0;
    char temp[1050] = {0};
    int i = 0, k = 0;
    int product = 0;

    while (digitA - i > 0 || carry > 0) {
        int numA = (digitA - i > 0) ? a[digitA - i - 1] - '0' : 0;

        product = numA * b + carry;
        temp[k] = (product % 10) + '0';
        carry = product / 10;

        k++;
        i++;
    }

    for (int j = 0; j < k; j++) {
        result[j] = temp[k - j - 1];
    }
    result[k] = '\0';
}

void rotate (int* matrix[256][256], int a1, int a2, int b1, int b2){


    int rows = b1 - a1 + 1;
    int cols = b2 - a2 + 1;

    int temp[256][256];

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            temp[cols - 1 - j][i] = matrix[a1 + i][a2 + j];
        }
    }

    for (int i = 0; i < cols; i++) {
        for (int j = 0; j < rows; j++) {
            matrix[a1 + i][a2 + j] = temp[i][j];
        }
    }


}

int main(){
    int width, numChanges;
    scanf("%d %d", &width, &numChanges);

    long long matrix[256][256];
    int k=1;
    char str[1050]="0";
    char wholeTotalBig[1050]="0";
    for (int i=0; i<width; i++){
        for (int j=0; j< width; j++){
            matrix[i][j]=k;
            k++;
            sprintf(str, "%lld", matrix[i][j]);
            addition(wholeTotalBig, wholeTotalBig, str );

        }
    }


    for (int times=0; times< numChanges; times++){

        int a1, a2, b1, b2;
        scanf("%d %d %d %d", &a1, &a2, &b1, &b2);
        int c1=a1-1, c2=a2-1, d1=b1+1, d2=b2+1;
        int temp;

        rotate (matrix, a1, a2, b1, b2);

        long long int total=0;

        char totalBig[1050]="0";
        for (int i=a1; i<=b1; i++){
            for (int j=a2; j<=b2; j++){
               sprintf(str,"%lld", matrix[i][j] );
               addition(totalBig, totalBig, str);

            }
        }

        multiply(totalBig, totalBig, 2);

        if (compare(totalBig, wholeTotalBig)){
              printf("Heavy Rotation!\n");
        }

        else printf("NoNo\n");

    }




}
