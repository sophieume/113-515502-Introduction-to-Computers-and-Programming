#include <stdio.h>
#include <string.h>

void Summarize(char* result, char* a, char* b) {
    int carry = 0;
    int len1 = strlen(a);
    int len2 = strlen(b);
    char temp[1050] = {0};
    int sum = 0;
    int i = 1;
    int k = 0;

    while (len1 - i >= 0 || len2 - i >= 0 || carry > 0) {
        int NumA = (len1 - i >= 0) ? a[len1 - i] - '0' : 0;
        int NumB = (len2 - i >= 0) ? b[len2 - i] - '0' : 0;

        sum = NumA + NumB + carry;
        carry = sum / 10;
        temp[k] = sum % 10 + '0';
        k++;
        i++;
    }

    for (int j = 0; j < k; j++) {
        result[j] = temp[k - j - 1];
    }
    result[k] = '\0';
}

void Multiply(char* result, char* a, int b) {
    int len = strlen(a);
    int carry = 0;
    char temp[1050] = {0};
    int i = 0, k = 0;
    int product = 0;

    while (len - i > 0 || carry > 0) {
        int NumA = (len - i > 0) ? a[len - i - 1] - '0' : 0;

        product = NumA * b + carry;
        temp[k] = (product % 10) + '0';
        carry = product / 10;

        k++;
        i++;
    }

    for (int j = 0; j < k; j++) {
        result[j] = temp[k - j - 1];
    }
    result[k] = '\0';
}

void MultiplyBig(char* result, char* a, char* b) {
    int len1 = strlen(a);
    int len2 = strlen(b);


    int temp[2100] = {0};


    for (int i = len1 - 1; i >= 0; i--) {
        for (int j = len2 - 1; j >= 0; j--) {
            int NumA = a[i] - '0';
            int NumB = b[j] - '0';


            temp[i + j + 1] += NumA * NumB;


            temp[i + j] += temp[i + j + 1] / 10;
            temp[i + j + 1] %= 10;
        }
    }


    int k = 0;
    int start = 0;


    while (start < len1 + len2 && temp[start] == 0) {
        start++;
    }


    if (start == len1 + len2) {
        result[k++] = '0';
    } else {
        for (int i = start; i < len1 + len2; i++) {
            result[k++] = temp[i] + '0';
        }
    }
    result[k] = '\0';
}

int Compare(char* a, char* b) {
    int len1 = strlen(a);
    int len2 = strlen(b);

    if (len1 > len2) return 1;
    if (len1 < len2) return 0;

    for (int i = 0; i < len1; i++) {
        if (a[i] > b[i]) return 1;
        if (a[i] < b[i]) return 0;
    }
    return 1;
}

int main() {
    int l;
    scanf("%d", &l);
    char H[l][1050];

    for (int i = 0; i < l; i++) {
        scanf("%s", H[i]);
    }

    for (int level = 0; level < l; level++) {
        char totalAttack[1050] = "0";

        int num_buffs[6];
        for (int i = 0; i < 6; i++) {
            scanf("%d", &num_buffs[i]);
        }

        char memberAttack[6][1050];


        for (int i = 0; i < 6; i++) {
            scanf("%s", memberAttack[i]);

            for (int j = 0; j < num_buffs[i]; j++) {
                char buff_value[1050];
                scanf("%s", buff_value);

                char temp[1050];
                MultiplyBig(temp, memberAttack[i], buff_value);
                strcpy(memberAttack[i], temp);
            }
        }

        for (int i = 0; i < 6; i++) {
            char tempTotal[1050]={0};
            Summarize(tempTotal, totalAttack, memberAttack[i]);
            strcpy(totalAttack, tempTotal);
        }


        if (Compare(totalAttack, H[level])) {
            printf("%s Yes\n", totalAttack);
        } else {
            printf("%s No\n", totalAttack);
        }
    }

    return 0;
}
